# test_analyzer_errors.py

import os
import sys
import tempfile
import shutil
from pathlib import Path

# To make sure the import works from the root directory
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from scorecard.parser import OpenAPIParser
from scorecard.analyzer import QualityAnalyzer

def setup_temp_specs():
    """
    Creates temporary directories and example spec files for error handling testing.
    Returns the path to the temporary directory.
    """
    temp_dir = Path(tempfile.gettempdir()) / 'scorecard_error_tests'
    temp_dir.mkdir(exist_ok=True)
    
    # Spec 1: Good Error Handling
    good_error_spec = """
openapi: 3.0.0
info:
  title: API with Good Error Handling
  version: 1.0.0
paths:
  /users/{userId}:
    get:
      summary: Get user details
      responses:
        '200':
          description: Successful response
          content:
            application/json:
              schema:
                type: object
        '404':
          description: User not found.
          content:
            application/json:
              schema:
                type: object
                properties:
                  code: { type: string }
                  message: { type: string }
        '500':
          description: Internal server error.
          content:
            application/json:
              schema:
                type: object
                properties:
                  code: { type: string }
                  message: { type: string }
"""
    
    # Spec 2: Poor Error Handling
    poor_error_spec = """
openapi: 3.0.0
info:
  title: API with Poor Error Handling
  version: 1.0.0
paths:
  /data:
    get:
      summary: Get some data
      responses:
        '200':
          description: A successful response.
          content:
            application/json:
              schema:
                type: object
"""
    
    with open(temp_dir / 'good_error.yaml', 'w') as f:
        f.write(good_error_spec)
        
    with open(temp_dir / 'poor_error.yaml', 'w') as f:
        f.write(poor_error_spec)

    return str(temp_dir)

def test_error_handling_score():
    """Test that the error handling score is calculated correctly."""
    print("🔍 Testing Error Handling Score...")
    temp_dir = setup_temp_specs()
    
    try:
        # Test good error spec (should be high)
        parser = OpenAPIParser(str(Path(temp_dir) / 'good_error.yaml'))
        parser.validate_spec()
        analyzer = QualityAnalyzer(parser)
        analysis_results = analyzer.analyze()
        error_score = analysis_results['category_scores']['errors']
        
        if error_score > 7: # Score should be high (max 10)
            print(f"  ✅ Good error handling API score is high: {error_score} (Pass)")
        else:
            print(f"  ❌ Good error handling API score is too low: {error_score} (Fail)")
            return False

        # Test poor error spec (should be low)
        parser = OpenAPIParser(str(Path(temp_dir) / 'poor_error.yaml'))
        parser.validate_spec()
        analyzer = QualityAnalyzer(parser)
        analysis_results = analyzer.analyze()
        error_score = analysis_results['category_scores']['errors']
        
        if error_score <= 3: # Score should be low
            print(f"  ✅ Poorly documented API score is low: {error_score} (Pass)")
        else:
            print(f"  ❌ Poorly documented API score is too high: {error_score} (Fail)")
            return False
            
        return True
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        
def main():
    """Runs all error handling analyzer tests."""
    print("🧪 API Quality Analyzer - Error Handling Test Suite")
    print("=" * 50)
    
    results = []
    
    try:
        results.append(test_error_handling_score())
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        results.append(False)
    
    print("\n" + "=" * 50)
    print("📊 Error Handling Test Results Summary:")
    
    passed = sum(results)
    total = len(results)
    
    if passed == total:
        print(f"🎉 All tests passed! ({passed}/{total})")
        print("\n✅ New error handling scoring is working correctly.")
        return 0
    else:
        print(f"❌ Some tests failed ({passed}/{total})")
        return 1

if __name__ == "__main__":
    sys.exit(main())
