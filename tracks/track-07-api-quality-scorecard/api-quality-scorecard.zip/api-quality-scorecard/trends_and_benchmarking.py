import requests
import yaml
import json
from collections import defaultdict

# NOTE: This script requires the `requests` and `PyYAML` libraries.
# You can install them using pip:
# pip install requests PyYAML

# --- CORE FUNCTIONALITY ---

def fetch_and_parse_spec(url):
    """
    Fetches and parses an OpenAPI/Swagger specification from a given URL.
    Handles both JSON and YAML formats.
    
    Args:
        url (str): The URL of the OpenAPI specification file.

    Returns:
        dict: The parsed API specification.
        str: The format of the specification ('json' or 'yaml').
    
    Raises:
        requests.exceptions.RequestException: If the URL is unreachable or invalid.
        ValueError: If the file format is not supported (neither JSON nor YAML).
    """
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status() # Raises an HTTPError for bad responses (4xx or 5xx)
        
        # Determine the file format based on content-type header or file extension
        content_type = response.headers.get('Content-Type', '').split(';')[0]
        
        # Try JSON first
        if 'application/json' in content_type or url.endswith(('.json', '.json.txt')):
            try:
                spec = response.json()
                return spec, 'json'
            except json.JSONDecodeError:
                pass # Fall through to try YAML

        # Try YAML
        if 'application/x-yaml' in content_type or url.endswith(('.yaml', '.yml', '.yaml.txt')):
            try:
                spec = yaml.safe_load(response.text)
                return spec, 'yaml'
            except yaml.YAMLError:
                pass # Fall through to error handling

        # If previous attempts failed, try to load as JSON from text, then YAML
        try:
            spec = json.loads(response.text)
            return spec, 'json'
        except json.JSONDecodeError:
            try:
                spec = yaml.safe_load(response.text)
                return spec, 'yaml'
            except yaml.YAMLError:
                raise ValueError("Could not determine or parse the specification format. "
                                 "Content is neither valid JSON nor YAML.")

    except requests.exceptions.RequestException as e:
        print(f"Error fetching the URL {url}: {e}")
        return None, None
    except ValueError as e:
        print(f"Error parsing the API specification from {url}: {e}")
        return None, None

def count_endpoints(spec):
    """Counts the number of endpoints in an OpenAPI spec."""
    if not spec or 'paths' not in spec:
        return 0
    return sum(len(methods) for methods in spec['paths'].values())

def count_operations(spec):
    """Counts the total number of operations (GET, POST, etc.) across all endpoints."""
    if not spec or 'paths' not in spec:
        return 0
    return sum(
        1 for methods in spec['paths'].values()
        for method in methods
        if method in ['get', 'post', 'put', 'delete', 'patch']
    )

def identify_common_issues(spec):
    """Identifies common issues like missing descriptions or examples."""
    issues = defaultdict(int)
    if not spec or 'paths' not in spec:
        return issues
    
    paths = spec['paths']
    for path, methods in paths.items():
        if 'description' not in spec.get('info', {}):
            issues['api_description_missing'] += 1
        
        for method, details in methods.items():
            if method.lower() in ['get', 'post', 'put', 'delete', 'patch']:
                if 'summary' not in details and 'description' not in details:
                    issues['operation_summary_missing'] += 1
                if 'responses' not in details or not details['responses']:
                    issues['responses_missing'] += 1
                for status_code, response_details in details.get('responses', {}).items():
                    if 'description' not in response_details:
                        issues['response_description_missing'] += 1
                    if 'content' in response_details:
                        for content_type, content_details in response_details['content'].items():
                            if 'example' not in content_details and 'examples' not in content_details:
                                issues['response_example_missing'] += 1
    return dict(issues)

def generate_report(metrics):
    """
    Generates a professional-quality report with actionable insights.
    
    Args:
        metrics (list of dicts): A list of metric dictionaries for each API.
    """
    print("--- API Benchmarking Report: Actionable Insights ---")
    print("\nOverview:")
    print("This report provides a comparative analysis of OpenAPI specifications to identify best practices and common areas for improvement.")
    
    total_apis = len(metrics)
    if total_apis == 0:
        print("No API data was provided to generate a report.")
        return
        
    # Aggregate data for a comprehensive view
    total_endpoints = sum(m['endpoints'] for m in metrics)
    total_operations = sum(m['operations'] for m in metrics)
    total_issues = defaultdict(int)
    for m in metrics:
        for issue, count in m['issues'].items():
            total_issues[issue] += count
    
    print(f"\nTotal APIs Analyzed: {total_apis}")
    print(f"Total Endpoints Discovered: {total_endpoints}")
    print(f"Total Operations Tracked: {total_operations}")
    
    print("\n--- Comparative Analysis ---")
    print("Metrics for each API:")
    for metric in metrics:
        print(f"\nAPI: {metric['name']}")
        print(f"  - Endpoints: {metric['endpoints']}")
        print(f"  - Operations: {metric['operations']}")
        print(f"  - Documented Issues:")
        if metric['issues']:
            for issue, count in metric['issues'].items():
                print(f"    - {issue.replace('_', ' ').capitalize()}: {count}")
        else:
            print("    - No significant issues found. This is a best-practice example.")
            
    print("\n--- Industry Benchmarks & Common Issues ---")
    if total_issues:
        print("Based on the analyzed APIs, the most common issues are:")
        sorted_issues = sorted(total_issues.items(), key=lambda item: item[1], reverse=True)
        for issue, count in sorted_issues:
            print(f"  - {issue.replace('_', ' ').capitalize()}: {count} occurrences")
            
    print("\n--- Recommendations for Improvement ---")
    print("To achieve best-in-class documentation and usability, we recommend the following:")
    if total_issues.get('operation_summary_missing', 0) > 0:
        print("- **Improve Readability:** Add `summary` and `description` to all operations for clear, human-readable documentation.")
    if total_issues.get('responses_missing', 0) > 0:
        print("- **Ensure Clarity:** All operations should define their possible `responses` to clearly communicate expected behavior.")
    if total_issues.get('response_example_missing', 0) > 0:
        print("- **Enhance Practicality:** Include `examples` for both request bodies and responses to show developers how to interact with your API.")
    if total_issues.get('api_description_missing', 0) > 0:
        print("- **Provide Context:** Ensure the top-level API `info` object has a `description` field to explain the API's overall purpose.")
    if not total_issues:
        print("All APIs analyzed show high-quality documentation. Continue to maintain these standards!")
    print("\n--- End of Report ---")

# --- BENCHMARK EXECUTION ---

def run_benchmarks():
    """
    Main function to run the benchmarking process on a set of APIs.
    """
    # These are placeholder URLs for popular APIs. In a real scenario, you would
    # replace these with the actual OpenAPI URLs of the APIs you want to benchmark.
    api_urls = {
        'Petstore API': 'https://petstore.swagger.io/v2/swagger.json',
        'Zendesk API': 'https://developer.zendesk.com/api-reference/ticketing/introduction.yaml', # Example, often requires authentication
        'JSONPlaceholder API': 'https://jsonplaceholder.typicode.com/swagger.json',
    }
    
    all_metrics = []
    
    print("Starting API analysis...")
    for name, url in api_urls.items():
        print(f"Analyzing {name} from {url}...")
        spec, fmt = fetch_and_parse_spec(url)
        if spec:
            metrics = {
                'name': name,
                'endpoints': count_endpoints(spec),
                'operations': count_operations(spec),
                'issues': identify_common_issues(spec)
            }
            all_metrics.append(metrics)
        else:
            print(f"Skipping {name} due to an error.")
            
    generate_report(all_metrics)

if __name__ == '__main__':
    run_benchmarks()

