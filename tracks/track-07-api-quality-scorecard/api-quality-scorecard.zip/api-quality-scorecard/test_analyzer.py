# test_analyzer.py

import os
import sys
from pathlib import Path
import yaml

# To make sure the import works from the root directory
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from scorecard.parser import OpenAPIParser
from scorecard.analyzer import QualityAnalyzer

def create_test_spec(file_name, content):
    """Utility function to create a test spec file."""
    test_dir = Path('examples')
    test_dir.mkdir(exist_ok=True)
    with open(test_dir / file_name, 'w') as f:
        f.write(content)

def setup_test_specs():
    """Creates various test spec files for the analyzer tests."""
    fully_documented_spec = """
openapi: 3.0.0
info:
  title: Fully Documented API
  description: This is a well-documented API.
  version: 1.0.0
paths:
  /users:
    get:
      summary: Get a list of users
      description: Retrieves a list of all user profiles.
      parameters:
        - name: page
          in: query
          description: The page number to retrieve.
          schema:
            type: integer
      responses:
        '200':
          description: A list of users.
          content:
            application/json:
              schema:
                type: array
                items:
                  type: object
                  properties:
                    id:
                      type: integer
                    name:
                      type: string
  /users/{id}:
    post:
      summary: Create a new user
      description: Creates a new user profile with a unique ID.
      requestBody:
        description: User profile information.
        content:
          application/json:
            schema:
              type: object
              required:
                - name
              properties:
                name:
                  type: string
                email:
                  type: string
      responses:
        '201':
          description: User created successfully.
"""
    minimal_spec = """
openapi: 3.0.0
info:
  title: Minimal API
  version: 1.0.0
paths:
  /status:
    get:
      responses:
        '200':
          description: OK
"""
    schema_only_spec = """
openapi: 3.0.0
info:
  title: Schema-Rich API
  version: 1.0.0
paths:
  /data:
    post:
      requestBody:
        content:
          application/json:
            schema:
              type: object
              required:
                - key
              properties:
                key:
                  type: string
      responses:
        '200':
          description: Success
          content:
            application/json:
              schema:
                type: object
                properties:
                  id:
                    type: string
"""
    create_test_spec('fully-documented-api.yaml', fully_documented_spec)
    create_test_spec('minimal-api.yaml', minimal_spec)
    create_test_spec('schema-only-api.yaml', schema_only_spec)

def test_documentation_scoring():
    """Test that the documentation score is calculated correctly."""
    print("🔍 Testing Documentation Scoring...")
    
    # Test a fully documented API
    try:
        parser = OpenAPIParser('examples/fully-documented-api.yaml')
        analyzer = QualityAnalyzer(parser)
        results = analyzer.analyze()
        doc_score = results['category_scores']['documentation']
        
        # We expect a high score, let's say >= 20
        if doc_score >= 20:
            print(f"  ✅ Fully documented API scored: {doc_score}/25 (Pass)")
            return True
        else:
            print(f"  ❌ Fully documented API scored: {doc_score}/25 (Expected >= 20)")
            return False
    except Exception as e:
        print(f"  ❌ Test failed with an unexpected error: {e}")
        return False

def test_schemas_scoring():
    """Test that the schemas score is calculated correctly."""
    print("\n🔍 Testing Schemas Scoring...")
    
    # Test a schema-only API
    try:
        parser = OpenAPIParser('examples/schema-only-api.yaml')
        analyzer = QualityAnalyzer(parser)
        results = analyzer.analyze()
        schemas_score = results['category_scores']['schemas']
        
        # We expect a high score, let's say >= 20
        if schemas_score >= 20:
            print(f"  ✅ Schema-only API scored: {schemas_score}/25 (Pass)")
            return True
        else:
            print(f"  ❌ Schema-only API scored: {schemas_score}/25 (Expected >= 20)")
            return False
    except Exception as e:
        print(f"  ❌ Test failed with an unexpected error: {e}")
        return False

def test_minimal_api_scoring():
    """Test that a minimal API scores low on both categories."""
    print("\n🔍 Testing Minimal API Scoring...")
    
    try:
        parser = OpenAPIParser('examples/minimal-api.yaml')
        analyzer = QualityAnalyzer(parser)
        results = analyzer.analyze()
        doc_score = results['category_scores']['documentation']
        schemas_score = results['category_scores']['schemas']
        
        # We expect scores to be very low, let's say <= 5 for each
        if doc_score <= 5 and schemas_score <= 5:
            print(f"  ✅ Minimal API scored low (Doc: {doc_score}, Schemas: {schemas_score}) (Pass)")
            return True
        else:
            print(f"  ❌ Minimal API scores were too high (Doc: {doc_score}, Schemas: {schemas_score}) (Expected <= 5)")
            return False
    except Exception as e:
        print(f"  ❌ Test failed with an unexpected error: {e}")
        return False

def main():
    """Run all analyzer tests."""
    print("🧪 API Quality Analyzer Test Suite")
    print("=" * 50)
    
    setup_test_specs()
    
    tests = [
        test_documentation_scoring,
        test_schemas_scoring,
        test_minimal_api_scoring
    ]
    
    results = []
    
    for test_func in tests:
        result = test_func()
        results.append(result)
    
    print("\n" + "=" * 50)
    print("📊 Test Results Summary:")
    
    passed = sum(results)
    total = len(results)
    
    if passed == total:
        print(f"🎉 All tests passed! ({passed}/{total})")
        print("\n✅ Analyzer implementation is ready for development")
        return 0
    else:
        print(f"❌ Some tests failed ({passed}/{total})")
        return 1

if __name__ == "__main__":
    sys.exit(main())
