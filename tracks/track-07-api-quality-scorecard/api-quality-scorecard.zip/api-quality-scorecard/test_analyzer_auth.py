# test_analyzer_auth.py

import os
import sys
import tempfile
import shutil
from pathlib import Path

# To make sure the import works from the root directory
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from scorecard.parser import OpenAPIParser
from scorecard.analyzer import QualityAnalyzer

def setup_temp_specs():
    """
    Creates temporary directories and example spec files for authentication testing.
    Returns the path to the temporary directory.
    """
    temp_dir = Path(tempfile.gettempdir()) / 'scorecard_auth_tests'
    temp_dir.mkdir(exist_ok=True)
    
    # Spec 1: Good Auth Documentation
    good_auth_spec = """
openapi: 3.0.0
info:
  title: API with Good Auth Docs
  version: 1.0.0
servers:
  - url: https://api.example.com
    description: Production server
security:
  - petstore_auth:
      - read:pets
      - write:pets
  - api_key: []
paths:
  /users/{userId}:
    get:
      summary: Get user details
      security:
        - petstore_auth:
            - read:users
      parameters:
        - name: userId
          in: path
          required: true
          description: The ID of the user to retrieve.
          schema:
            type: string
      responses:
        '200':
          description: OK
components:
  securitySchemes:
    petstore_auth:
      type: oauth2
      description: OAuth2 security scheme for the Pet Store API.
      flows:
        authorizationCode:
          authorizationUrl: https://example.com/oauth/authorize
          tokenUrl: https://example.com/oauth/token
          scopes:
            read:pets: Read your pets
            write:pets: Modify your pets
    api_key:
      type: apiKey
      description: API key required for authentication.
      name: api_key
      in: header
"""
    
    # Spec 2: Poor Auth Documentation
    poor_auth_spec = """
openapi: 3.0.0
info:
  title: API with No Auth Docs
  version: 1.0.0
paths:
  /data/{dataId}:
    get:
      summary: Get some data
      parameters:
        - name: dataId
          in: path
          required: true
          description: The ID of the data to retrieve.
          schema:
            type: string
      responses:
        '200':
          description: A successful response.
"""
    
    with open(temp_dir / 'good_auth.yaml', 'w') as f:
        f.write(good_auth_spec)
        
    with open(temp_dir / 'poor_auth.yaml', 'w') as f:
        f.write(poor_auth_spec)

    return str(temp_dir)

def test_auth_score():
    """Test that the authentication score is calculated correctly."""
    print("🔍 Testing Authentication Score...")
    temp_dir = setup_temp_specs()
    
    try:
        # Test good auth spec (should be high)
        parser = OpenAPIParser(str(Path(temp_dir) / 'good_auth.yaml'))
        parser.validate_spec()
        analyzer = QualityAnalyzer(parser)
        analysis_results = analyzer.analyze()
        auth_score = analysis_results['category_scores']['auth']
        
        if auth_score > 7: # Score should be high (max 10)
            print(f"  ✅ Good auth docs API score is high: {auth_score} (Pass)")
        else:
            print(f"  ❌ Good auth docs API score is too low: {auth_score} (Fail)")
            return False

        # Test poor auth spec (should be low)
        parser = OpenAPIParser(str(Path(temp_dir) / 'poor_auth.yaml'))
        parser.validate_spec()
        analyzer = QualityAnalyzer(parser)
        analysis_results = analyzer.analyze()
        auth_score = analysis_results['category_scores']['auth']
        
        if auth_score <= 3: # Score should be low
            print(f"  ✅ Poor auth docs API score is low: {auth_score} (Pass)")
        else:
            print(f"  ❌ Poor auth docs API score is too high: {auth_score} (Fail)")
            return False
            
        return True
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        
def main():
    """Runs all authentication analyzer tests."""
    print("🧪 API Quality Analyzer - Authentication Test Suite")
    print("=" * 50)
    
    results = []
    
    try:
        results.append(test_auth_score())
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        results.append(False)
    
    print("\n" + "=" * 50)
    print("📊 Authentication Test Results Summary:")
    
    passed = sum(results)
    total = len(results)
    
    if passed == total:
        print(f"🎉 All tests passed! ({passed}/{total})")
        print("\n✅ New authentication scoring is working correctly.")
        return 0
    else:
        print(f"❌ Some tests failed ({passed}/{total})")
        return 1

if __name__ == "__main__":
    sys.exit(main())
