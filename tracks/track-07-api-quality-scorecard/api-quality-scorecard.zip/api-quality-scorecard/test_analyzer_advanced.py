# test_analyzer_advanced.py

import os
import sys
import tempfile
import shutil
from pathlib import Path

# To make sure the import works from the root directory
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from scorecard.parser import OpenAPIParser
from scorecard.analyzer import QualityAnalyzer

def setup_temp_specs():
    """
    Creates temporary directories and example spec files for advanced testing.
    Returns the path to the temporary directory.
    """
    temp_dir = Path(tempfile.gettempdir()) / 'scorecard_advanced_tests'
    temp_dir.mkdir(exist_ok=True)
    
    # Spec 1: Fully Agent-Optimized API (should score high on new metrics)
    optimized_spec = """
openapi: 3.0.0
info:
  title: Agent-Optimized API
  description: An API designed for easy agent consumption.
  version: 1.0.0
paths:
  /products/{productId}:
    get:
      summary: Get a product by its ID
      operationId: getProductById
      tags:
        - products
      parameters:
        - name: productId
          in: path
          description: Unique ID of the product.
          required: true
          schema:
            type: string
      responses:
        '200':
          description: The product information.
          content:
            application/json:
              schema:
                type: object
                properties:
                  id: { type: string }
                  name: { type: string }
                  price: { type: number }
  /users:
    post:
      summary: Create a new user account
      operationId: createUserAccount
      tags:
        - users
      requestBody:
        description: User data to create.
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [username, email]
              properties:
                username:
                  type: string
                email:
                  type: string
      responses:
        '201':
          description: User created successfully.
"""
    
    # Spec 2: Poorly-Designed API (should score low on new metrics)
    poorly_designed_spec = """
openapi: 3.0.0
info:
  title: Bad API
  version: 1.0.0
paths:
  /items:
    get:
      summary: Get data.
      description: Just some data.
      parameters:
        - name: p1
          in: query
          schema: { type: string }
        - name: p2
          in: query
          schema: { type: string }
        - name: p3
          in: query
          schema: { type: string }
        - name: p4
          in: query
          schema: { type: string }
        - name: p5
          in: query
          schema: { type: string }
        - name: p6
          in: query
          schema: { type: string }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema:
                type: object
                properties:
                  data:
                    type: object
                    properties:
                      details:
                        type: object
                        properties:
                          info:
                            type: object
                            properties:
                              nested:
                                type: string
"""
    
    with open(temp_dir / 'optimized.yaml', 'w') as f:
        f.write(optimized_spec)
        
    with open(temp_dir / 'poorly-designed.yaml', 'w') as f:
        f.write(poorly_designed_spec)

    return str(temp_dir)

def test_naming_score():
    """Test that the naming score is calculated correctly."""
    print("🔍 Testing Naming Score...")
    temp_dir = setup_temp_specs()
    
    try:
        # Test optimized spec (should be high)
        parser = OpenAPIParser(str(Path(temp_dir) / 'optimized.yaml'))
        parser.validate_spec()
        analyzer = QualityAnalyzer(parser)
        analysis_results = analyzer.analyze()
        naming_score = analysis_results['category_scores']['naming']
        
        if naming_score > 7: # Score should be high (max 10)
            print(f"  ✅ Optimized API naming score is high: {naming_score} (Pass)")
        else:
            print(f"  ❌ Optimized API naming score is too low: {naming_score} (Fail)")
            return False

        # Test poorly designed spec (should be low)
        parser = OpenAPIParser(str(Path(temp_dir) / 'poorly-designed.yaml'))
        parser.validate_spec()
        analyzer = QualityAnalyzer(parser)
        analysis_results = analyzer.analyze()
        naming_score = analysis_results['category_scores']['naming']
        
        if naming_score <= 3: # Score should be low
            print(f"  ✅ Poorly designed API naming score is low: {naming_score} (Pass)")
        else:
            print(f"  ❌ Poorly designed API naming score is too high: {naming_score} (Fail)")
            return False
            
        return True
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def test_discoverability_score():
    """Test that the discoverability score is calculated correctly."""
    print("\n🔍 Testing Discoverability Score...")
    temp_dir = setup_temp_specs()
    
    try:
        # Test optimized spec (should be high)
        parser = OpenAPIParser(str(Path(temp_dir) / 'optimized.yaml'))
        parser.validate_spec()
        analyzer = QualityAnalyzer(parser)
        analysis_results = analyzer.analyze()
        discoverability_score = analysis_results['category_scores']['discoverability']

        if discoverability_score > 7: # Score should be high (max 10)
            print(f"  ✅ Optimized API discoverability score is high: {discoverability_score} (Pass)")
        else:
            print(f"  ❌ Optimized API discoverability score is too low: {discoverability_score} (Fail)")
            return False

        # Test poorly designed spec (should be low)
        parser = OpenAPIParser(str(Path(temp_dir) / 'poorly-designed.yaml'))
        parser.validate_spec()
        analyzer = QualityAnalyzer(parser)
        analysis_results = analyzer.analyze()
        discoverability_score = analysis_results['category_scores']['discoverability']

        if discoverability_score <= 3: # Score should be low
            print(f"  ✅ Poorly designed API discoverability score is low: {discoverability_score} (Pass)")
        else:
            print(f"  ❌ Poorly designed API discoverability score is too high: {discoverability_score} (Fail)")
            return False

        return True
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        
def test_complexity_score():
    """Test that the complexity score is calculated correctly."""
    print("\n🔍 Testing Complexity Score...")
    temp_dir = setup_temp_specs()
    
    try:
        # Test optimized spec (should be high)
        parser = OpenAPIParser(str(Path(temp_dir) / 'optimized.yaml'))
        parser.validate_spec()
        analyzer = QualityAnalyzer(parser)
        analysis_results = analyzer.analyze()
        complexity_score = analysis_results['category_scores']['complexity']

        if complexity_score > 3: # Score should be high (max 5)
            print(f"  ✅ Optimized API complexity score is high: {complexity_score} (Pass)")
        else:
            print(f"  ❌ Optimized API complexity score is too low: {complexity_score} (Fail)")
            return False

        # Test poorly designed spec (should be low)
        parser = OpenAPIParser(str(Path(temp_dir) / 'poorly-designed.yaml'))
        parser.validate_spec()
        analyzer = QualityAnalyzer(parser)
        analysis_results = analyzer.analyze()
        complexity_score = analysis_results['category_scores']['complexity']

        if complexity_score <= 1: # Score should be low
            print(f"  ✅ Poorly designed API complexity score is low: {complexity_score} (Pass)")
        else:
            print(f"  ❌ Poorly designed API complexity score is too high: {complexity_score} (Fail)")
            return False
            
        return True
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
        
def main():
    """Runs all advanced analyzer tests."""
    print("🧪 API Quality Analyzer - Advanced Test Suite")
    print("=" * 50)
    
    tests = [
        test_naming_score,
        test_discoverability_score,
        test_complexity_score,
    ]
    
    results = []
    
    for test_func in tests:
        try:
            result = test_func()
            results.append(result)
        except Exception as e:
            print(f"❌ Test {test_func.__name__} failed with error: {e}")
            results.append(False)
    
    print("\n" + "=" * 50)
    print("📊 Advanced Test Results Summary:")
    
    passed = sum(results)
    total = len(results)
    
    if passed == total:
        print(f"🎉 All tests passed! ({passed}/{total})")
        print("\n✅ New agent-focused scoring is working correctly.")
        return 0
    else:
        print(f"❌ Some tests failed ({passed}/{total})")
        return 1

if __name__ == "__main__":
    sys.exit(main())
