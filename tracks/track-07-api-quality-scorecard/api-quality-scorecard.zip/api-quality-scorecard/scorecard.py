# scorecard.py
#
# This script analyzes an OpenAPI specification for quality using a modular approach.

import click
import os
import sys
import json
import yaml
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

# Import our new modules
from scorecard.parser import OpenAPIParser
from scorecard.analyzer import QualityAnalyzer
from scorecard.reporter import Reporter

def _load_historical_data(history_path):
    """
    Loads historical analysis data from a JSON file or a directory of files.
    """
    history_path = Path(history_path)
    
    if not history_path.exists():
        click.echo(f"❌ Error: Historical data not found at: {history_path}", err=True)
        return None
    
    if history_path.is_file():
        try:
            with open(history_path, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            click.echo(f"❌ Error decoding JSON file: {e}", err=True)
            return None
    
    elif history_path.is_dir():
        # For directory, we'll load the most recent file
        try:
            json_files = sorted(history_path.glob("*.json"), key=os.path.getmtime, reverse=True)
            if not json_files:
                click.echo(f"❌ Error: No JSON files found in directory: {history_path}", err=True)
                return None
            
            with open(json_files[0], 'r') as f:
                click.echo(f"✅ Comparing against most recent historical data: {json_files[0]}")
                return json.load(f)
        except Exception as e:
            click.echo(f"❌ Error loading historical data from directory: {e}", err=True)
            return None
            
    return None

def _save_history(spec_name, results):
    """
    Saves the analysis results to a timestamped JSON file.
    """
    history_dir = Path("history")
    history_dir.mkdir(exist_ok=True)
    
    timestamp = datetime.now().isoformat(timespec='seconds').replace(':', '-')
    filename = f"{spec_name.split('.')[0]}-{timestamp}.json"
    filepath = history_dir / filename
    
    with open(filepath, 'w') as f:
        json.dump(results, f, indent=4)
    
    click.echo(f"💾 Analysis saved to: {filepath}")

def _load_profile(profile_path):
    """
    Loads a custom scoring profile from a YAML or JSON file.
    """
    profile_path = Path(profile_path)
    if not profile_path.exists():
        click.echo(f"❌ Error: Profile file not found at: {profile_path}", err=True)
        sys.exit(1)
        
    try:
        with open(profile_path, 'r', encoding='utf-8') as f:
            if profile_path.suffix.lower() in ['.yaml', '.yml']:
                return yaml.safe_load(f)
            else:
                return json.load(f)
    except (json.JSONDecodeError, yaml.YAMLError) as e:
        click.echo(f"❌ Error decoding profile file: {e}", err=True)
        sys.exit(1)

def _process_file(spec_path, output, format, detailed, quiet, threshold, save, compare_path, profile_data):
    """
    Core logic to process a single OpenAPI specification file.
    """
    
    if not quiet:
        click.echo("=" * 50)
        click.echo(f"Analyzing: {spec_path}")
        click.echo("=" * 50)
        click.echo()

    try:
        # 1. Parse the OpenAPI specification
        if not quiet:
            click.echo("📖 Parsing OpenAPI specification...")
        
        # Add this line for debugging to see the resolved absolute path
        resolved_path = Path(spec_path).resolve()
        click.echo(f"Debug: Attempting to access file at resolved path: {resolved_path}")
        
        parser = OpenAPIParser(spec_path)
        if not parser.validate_spec():
            # If validation fails, gracefully exit for this file but continue with others
            return False
        
        # 2. Analyze the specification
        if not quiet:
            click.echo("🔬 Analyzing API quality...")
        
        analyzer = QualityAnalyzer(parser)
        results = analyzer.analyze(scoring_profile=profile_data)
        
        # Save results to history if requested
        if save:
            _save_history(Path(spec_path).name, results)
        
        # 3. Generate report
        if not quiet:
            click.echo("📊 Generating report...")
        
        reporter = Reporter(results, Path(spec_path).name)
        report_content = ""
        
        if compare_path:
            historical_data = _load_historical_data(compare_path)
            if historical_data:
                reporter.set_historical_data(historical_data)
                report_content = reporter.generate_comparison_report()
            else:
                click.echo("❌ Skipping comparative analysis due to error loading historical data.", err=True)
                report_content = reporter.generate_markdown_summary()
        elif format == 'html':
            report_content = reporter.generate_html_report()
        elif format == 'json':
            report_content = reporter.generate_json_report()
        elif format == 'markdown':
            report_content = reporter.generate_markdown_summary()
        
        # Display results
        if not quiet:
            click.echo(report_content)
        
        # Save report if output specified
        if output:
            # Construct a unique output path for each file in batch mode
            output_path = Path(output).parent / f"{Path(spec_path).stem}_{Path(output).name}"
            with open(output_path, 'w') as f:
                f.write(report_content)
            if not quiet:
                click.echo(f"📁 Report saved to: {output_path}")
        
        # Check against threshold
        score = results['overall_score']
        if score < threshold:
            if not quiet:
                click.echo(f"\n⚠️  Score {score} below threshold {threshold}")
            return False # Indicate failure
        else:
            if not quiet:
                click.echo(f"\n✅ Score {score} meets threshold {threshold}")
            return True # Indicate success
            
    except FileNotFoundError:
        click.echo(f"❌ Error: File not found: {spec_path}", err=True)
        return False
    except Exception as e:
        click.echo(f"❌ Error analyzing specification: {e}", err=True)
        if not quiet:
            click.echo("\n💡 Troubleshooting tips:")
            click.echo("  - Verify the OpenAPI specification is valid")
            click.echo("  - Check file permissions and network connectivity")
            click.echo("  - Try with a simpler specification first")
        return False

@click.command()
@click.argument('spec_paths', nargs=-1)
@click.option('--output', '-o', help='Output file path for report')
@click.option('--format', '-f', 
              type=click.Choice(['html', 'json', 'markdown'], case_sensitive=False),
              default='markdown', 
              help='Output format for report')
@click.option('--detailed', '-d', is_flag=True, help='Generate detailed analysis')
@click.option('--quiet', '-q', is_flag=True, help='Suppress console output')
@click.option('--threshold', '-t', type=int, default=80, 
              help='Minimum score threshold (default: 80)')
@click.option('--save', '-s', is_flag=True, help='Save analysis results to history directory')
@click.option('--compare', '-c', type=click.Path(exists=True), help='Path to a historical JSON report or a history directory to compare against.')
@click.option('--profile', '-p', type=click.Path(exists=True), help='Path to a custom scoring profile file (YAML or JSON).')
def main(spec_paths, output, format, detailed, quiet, threshold, save, compare, profile):
    """
    Analyze OpenAPI specification for agent-readiness and quality.
    
    SPEC_PATHS can be one or more local file paths.
    
    Examples:
        scorecard.py api.yaml
        scorecard.py spec.yaml api.yaml
        scorecard.py --output report.html --format html spec1.yaml spec2.yaml
        scorecard.py spec.yaml --save
        scorecard.py spec.yaml --compare history/some_file.json
        scorecard.py spec.yaml --compare history/
        scorecard.py spec.yaml --profile my_profile.json
    """
    
    if not spec_paths:
        click.echo("No specification file(s) provided. Please provide one or more paths.", err=True)
        sys.exit(1)
        
    profile_data = None
    if profile:
        profile_data = _load_profile(profile)

    overall_success = True
    for path in spec_paths:
        if not _process_file(path, output, format, detailed, quiet, threshold, save, compare, profile_data):
            overall_success = False

    if overall_success:
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == '__main__':
    # Load environment variables
    load_dotenv()
    
    # Run CLI
    main()
