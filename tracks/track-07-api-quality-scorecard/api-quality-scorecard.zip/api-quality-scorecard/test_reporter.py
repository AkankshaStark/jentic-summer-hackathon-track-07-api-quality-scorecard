# test_reporter.py

import os
import sys
import tempfile
from pathlib import Path

# To make sure the import works from the root directory
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from scorecard.reporter import ReportGenerator

def create_temp_spec(content):
    """Creates a temporary OpenAPI spec file for testing and returns its path."""
    temp_dir = Path(tempfile.gettempdir()) / 'scorecard_tests'
    temp_dir.mkdir(exist_ok=True)
    temp_file = temp_dir / 'test-spec.yaml'
    with open(temp_file, 'w') as f:
        f.write(content)
    return str(temp_file)

def test_report_generation():
    """Test that a report is generated correctly for a valid spec."""
    print("🔍 Testing Report Generation for a valid spec...")
    
    # Create a simple valid spec for testing
    test_spec_content = """
openapi: 3.0.0
info:
  title: Test Report API
  description: A test API for the report generator.
  version: 1.0.0
paths:
  /test:
    get:
      summary: A test endpoint.
      responses:
        '200':
          description: OK
"""
    spec_path = create_temp_spec(test_spec_content)
    
    try:
        reporter = ReportGenerator()
        report = reporter.generate_report(spec_path)
        
        # Check for key phrases in the generated report
        if "Overall Score:" in report and "Documentation Quality:" in report and "Schema Completeness:" in report:
            print("  ✅ Report contains expected sections. (Pass)")
            return True
        else:
            print("  ❌ Report is missing key sections. (Fail)")
            print("Generated Report:\n", report)
            return False
            
    except Exception as e:
        print(f"  ❌ Test failed with an unexpected error: {e}")
        return False
    finally:
        # Clean up the temporary file
        os.remove(spec_path)

def test_non_existent_file():
    """Test that the report generator handles a missing file correctly."""
    print("\n🔍 Testing Report Generation with a non-existent file...")
    
    non_existent_path = "non-existent-file.yaml"
    
    try:
        reporter = ReportGenerator()
        report = reporter.generate_report(non_existent_path)
        
        # Check for the specific error message
        if "Error: The file at" in report and "was not found" in report:
            print("  ✅ Correctly handled non-existent file error. (Pass)")
            return True
        else:
            print("  ❌ Incorrect error handling for non-existent file.")
            print("Generated Report:\n", report)
            return False
            
    except Exception as e:
        print(f"  ❌ Test failed with an unexpected error: {e}")
        return False

def main():
    """Run all reporter tests."""
    print("🧪 API Quality Reporter Test Suite")
    print("=" * 50)
    
    results = []
    
    results.append(test_report_generation())
    results.append(test_non_existent_file())
    
    print("\n" + "=" * 50)
    print("📊 Test Results Summary:")
    
    passed = sum(results)
    total = len(results)
    
    if passed == total:
        print(f"🎉 All tests passed! ({passed}/{total})")
        print("\n✅ Report Generator is working correctly")
        return 0
    else:
        print(f"❌ Some tests failed ({passed}/{total})")
        return 1

if __name__ == "__main__":
    sys.exit(main())
