# scorecard/parser.py

import os
import json
import yaml
from openapi_spec_validator import validate
from jsonschema.exceptions import ValidationError
from pathlib import Path
import requests
from urllib.parse import urlparse

class OpenAPIParser:
    """
    Parses and validates OpenAPI Specification files (YAML or JSON).
    """

    def __init__(self, spec_path: str):
        self.spec_path = spec_path
        self._spec_data = None
        self._is_valid = False

    def _is_url(self, path: str) -> bool:
        """Helper function to check if a path is a URL."""
        try:
            result = urlparse(path)
            # Use 'scheme' for protocol (http/https) and 'netloc' for hostname
            return all([result.scheme in ['http', 'https'], result.netloc])
        except ValueError:
            return False

    def _load_spec(self) -> dict:
        """Loads the OpenAPI specification from the given file path or URL."""
        if self._is_url(self.spec_path):
            try:
                response = requests.get(self.spec_path, timeout=10)
                response.raise_for_status()
                if response.headers.get('Content-Type', '').find('json') != -1:
                    return response.json()
                else:
                    return yaml.safe_load(response.text)
            except requests.exceptions.RequestException as e:
                raise FileNotFoundError(f"Error fetching the URL {self.spec_path}: {e}")
        else:
            local_path = Path(self.spec_path)
            if not local_path.exists():
                raise FileNotFoundError(f"OpenAPI spec file not found at: {local_path}")
            
            file_extension = local_path.suffix.lower()
            try:
                with open(local_path, 'r', encoding='utf-8') as file:
                    if file_extension in ['.yaml', '.yml']:
                        return yaml.safe_load(file)
                    elif file_extension == '.json':
                        return json.load(file)
                    else:
                        raise ValueError("Unsupported file format. Please provide a YAML or JSON file.")
            except (yaml.YAMLError, json.JSONDecodeError) as e:
                raise ValueError(f"Error decoding spec file. Ensure it is valid YAML or JSON. Error: {e}")

    def validate_spec(self) -> bool:
        """
        Validates the loaded OpenAPI specification.

        Returns:
            bool: True if the spec is valid, False otherwise.
        """
        try:
            self._spec_data = self._load_spec()
            validate(self._spec_data)
            self._is_valid = True
            return True
        except (ValidationError, ValueError, FileNotFoundError, requests.exceptions.RequestException) as e:
            # We want to catch the specific FileNotFoundError here for better messaging
            if not isinstance(e, FileNotFoundError):
                print(f"Validation failed for {self.spec_path}: {e}")
            else:
                print(e)
            self._is_valid = False
            return False
    
    @property
    def spec_data(self):
        """Returns the loaded and validated specification data."""
        return self._spec_data
    
    def get_components(self) -> dict:
        """Extracts key components from a validated OpenAPI specification."""
        if not self._is_valid or not isinstance(self._spec_data, dict):
            return {}

        paths = self._spec_data.get('paths', {})
        components = self._spec_data.get('components', {})
        schemas = components.get('schemas', {})
        security_schemes = components.get('securitySchemes', {})

        return {
            "paths": paths,
            "schemas": schemas,
            "security_schemes": security_schemes
        }
    
    def get_summary_and_description(self):
        """Retrieves the API's title, summary, and description."""
        info = self._spec_data.get('info', {})
        return {
            'summary': info.get('title', 'No Title'),
            'description': info.get('description', 'No Description')
        }
