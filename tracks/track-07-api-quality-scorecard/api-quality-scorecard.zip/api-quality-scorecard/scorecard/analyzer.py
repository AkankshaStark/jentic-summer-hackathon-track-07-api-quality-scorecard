# scorecard/analyzer.py

import sys
import re

# Append the parent directory to the system path to allow importing the parser
sys.path.append('..')
from scorecard.parser import OpenAPIParser

class QualityAnalyzer:
    """
    Analyzes an OpenAPI specification and generates a quality score.
    
    This class contains methods for scoring different aspects of an API spec,
    such as documentation, schema completeness, error handling, etc., based on
    a detailed scoring framework.
    """
    
    def __init__(self, parser):
        """
        Initializes the analyzer with a parser instance.

        Args:
            parser (OpenAPIParser): An instance of the OpenAPIParser class
                                     that has already loaded a specification.
        """
        self.parser = parser
        # Initialize scores based on the new framework
        self.scores = {
            'documentation': 0,
            'schemas': 0,
            'errors': 0,
            'usability': 0,
            'auth': 0,
        }
        self.total_operations = 0
        self.issues_found = []
        self.recommendations = []
        
        # Breakdown of points for each category as per the framework
        self.scoring_breakdown = {
            'documentation': {
                'operation_descriptions': 8,
                'parameter_descriptions': 7,
                'examples': 5,
                'summary_and_tags': 5,
            },
            'schemas': {
                'request_schemas': 8,
                'response_schemas': 8,
                'parameter_types': 5,
                'required_fields': 4,
            },
            'errors': {
                'error_responses': 8,
                'error_schemas': 6,
                'status_code_coverage': 4,
                'error_examples': 2,
            },
            'usability': {
                'operation_naming': 6,
                'discoverability': 5,
                'complexity': 5,
                'consistency': 4,
            },
            'auth': {
                'security_schemes': 4,
                'auth_examples': 3,
                'scope_definitions': 2,
                'auth_flow_docs': 1,
            }
        }

    def analyze(self):
        """
        The main method to run the complete analysis.

        Returns:
            dict: A dictionary containing the overall score, category scores,
                  and a summary of findings.
        """
        if not self.parser.is_valid:
            return {
                'overall_score': 0,
                'category_scores': self.scores,
                'total_operations': 0,
                'issues_found': ["Invalid OpenAPI specification. Analysis failed."],
                'recommendations': ["Validate your OpenAPI spec using a tool like Spectral or the OpenAPI Spec Validator."]
            }

        # Analyze each category
        self.scores['documentation'] = self.score_documentation()
        self.scores['schemas'] = self.score_schemas()
        self.scores['errors'] = self.score_errors()
        self.scores['usability'] = self.score_usability()
        self.scores['auth'] = self.score_auth()

        # Calculate total weighted score
        total_score = sum(self.scores.values())

        return {
            'overall_score': total_score,
            'category_scores': self.scores,
            'total_operations': self.total_operations,
            'issues_found': list(set(self.issues_found)),  # Remove duplicates
            'recommendations': list(set(self.recommendations)) # Remove duplicates
        }

    def score_documentation(self):
        """Scores documentation quality based on the framework."""
        raw_score = 0
        max_score = 25
        
        info = self.parser.spec_data.get('info', {})
        if info.get('description'):
            raw_score += self.scoring_breakdown['documentation']['operation_descriptions']
        else:
            self.recommendations.append("The API's 'info' object should have a comprehensive 'description'.")

        self.total_operations = 0
        if 'paths' in self.parser.spec_data:
            for path, methods in self.parser.spec_data['paths'].items():
                for method, operation in methods.items():
                    self.total_operations += 1
                    
                    # Check for summary and tags (5 points)
                    if operation.get('summary') and operation.get('tags'):
                        raw_score += self.scoring_breakdown['documentation']['summary_and_tags'] / self.total_operations
                    elif not operation.get('summary'):
                        self.recommendations.append(f"Add a 'summary' for the '{method.upper()} {path}' operation.")
                    elif not operation.get('tags'):
                        self.recommendations.append(f"Add a 'tags' field to the '{method.upper()} {path}' operation to group related endpoints.")

                    # Check for operation descriptions (8 points)
                    if operation.get('description'):
                        raw_score += self.scoring_breakdown['documentation']['operation_descriptions'] / self.total_operations
                    else:
                        self.recommendations.append(f"Add a detailed 'description' for the '{method.upper()} {path}' operation.")

                    # Check for examples (5 points)
                    if 'requestBody' in operation:
                        request_body = operation['requestBody']
                        content = request_body.get('content', {})
                        for media_type in content.values():
                            if media_type.get('example') or media_type.get('examples'):
                                raw_score += self.scoring_breakdown['documentation']['examples'] / self.total_operations
                                break
                        else:
                            self.recommendations.append(f"Add a request body 'example' for the '{method.upper()} {path}' operation.")
                    if 'responses' in operation:
                        responses = operation['responses']
                        for status_code, response_obj in responses.items():
                            content = response_obj.get('content', {})
                            for media_type in content.values():
                                if media_type.get('example') or media_type.get('examples'):
                                    raw_score += self.scoring_breakdown['documentation']['examples'] / (self.total_operations * len(responses))
                    
                    # Check for parameter descriptions (7 points)
                    if 'parameters' in operation:
                        all_params_have_desc = all('description' in p for p in operation['parameters'])
                        if all_params_have_desc:
                            raw_score += self.scoring_breakdown['documentation']['parameter_descriptions'] / self.total_operations
                        else:
                            for param in operation['parameters']:
                                if 'description' not in param:
                                    self.recommendations.append(f"Add a 'description' for the '{param.get('name')}' parameter in '{method.upper()} {path}'.")
        
        return min(100, (raw_score / sum(self.scoring_breakdown['documentation'].values())) * 100) if raw_score > 0 else 0

    def score_schemas(self):
        """Scores schema completeness based on the framework."""
        raw_score = 0
        max_score = 25
        
        if 'paths' in self.parser.spec_data:
            for path, methods in self.parser.spec_data['paths'].items():
                for method, operation in methods.items():
                    # Request schemas (8 points)
                    if 'requestBody' in operation:
                        content = operation['requestBody'].get('content', {})
                        if 'application/json' in content and 'schema' in content['application/json']:
                            raw_score += self.scoring_breakdown['schemas']['request_schemas']
                        else:
                            self.recommendations.append(f"Define a request schema for the '{method.upper()} {path}' operation.")
                    
                    # Response schemas (8 points)
                    if 'responses' in operation:
                        for status_code, response_obj in operation['responses'].items():
                            content = response_obj.get('content', {})
                            if 'application/json' in content and 'schema' in content['application/json']:
                                raw_score += self.scoring_breakdown['schemas']['response_schemas']
                                break
                        else:
                            self.recommendations.append(f"Add response schemas for the '{method.upper()} {path}' operation.")
                            
                    # Required fields (4 points)
                    if 'requestBody' in operation and 'application/json' in operation['requestBody'].get('content', {}):
                        schema = operation['requestBody']['content']['application/json'].get('schema', {})
                        if 'required' in schema and len(schema['required']) > 0:
                            raw_score += self.scoring_breakdown['schemas']['required_fields']
                        else:
                            self.recommendations.append(f"Specify 'required' fields in the request schema for '{method.upper()} {path}'.")
        
        return min(100, (raw_score / sum(self.scoring_breakdown['schemas'].values())) * 100) if raw_score > 0 else 0

    def score_errors(self):
        """Scores error handling based on the framework."""
        raw_score = 0
        max_score = 20

        if 'paths' in self.parser.spec_data:
            for path, methods in self.parser.spec_data['paths'].items():
                for method, operation in methods.items():
                    responses = operation.get('responses', {})
                    
                    # Error responses (8 points)
                    if any(code.startswith('4') or code.startswith('5') for code in responses.keys()):
                        raw_score += self.scoring_breakdown['errors']['error_responses']
                    else:
                        self.recommendations.append(f"The '{method.upper()} {path}' operation is missing documentation for common client (4xx) and server (5xx) errors.")

                    # Error schemas (6 points)
                    if any('schema' in responses[code].get('content', {}).get('application/json', {}) for code in responses.keys() if code.startswith('4') or code.startswith('5')):
                        raw_score += self.scoring_breakdown['errors']['error_schemas']
                    else:
                        self.recommendations.append(f"Define schemas for common error responses (4xx, 5xx) in '{method.upper()} {path}'.")

                    # Error examples (2 points)
                    if any('example' in responses[code].get('content', {}).get('application/json', {}) for code in responses.keys() if code.startswith('4') or code.startswith('5')):
                        raw_score += self.scoring_breakdown['errors']['error_examples']
                    else:
                        self.recommendations.append(f"Provide examples for error responses in '{method.upper()} {path}'.")
                        
        return min(100, (raw_score / sum(self.scoring_breakdown['errors'].values())) * 100) if raw_score > 0 else 0

    def score_usability(self):
        """Scores agent usability based on the framework."""
        raw_score = 0
        max_score = 20
        
        if 'paths' in self.parser.spec_data:
            for path, methods in self.parser.spec_data['paths'].items():
                for method, operation in methods.items():
                    # Operation Naming (6 points) & Discoverability (5 points)
                    if operation.get('operationId'):
                        raw_score += self.scoring_breakdown['usability']['operation_naming']
                    else:
                        self.recommendations.append(f"The '{method.upper()} {path}' operation is missing a descriptive 'operationId'.")
                    
                    if operation.get('tags'):
                        raw_score += self.scoring_breakdown['usability']['discoverability']
                    else:
                        self.recommendations.append(f"Add a 'tags' field to the '{method.upper()} {path}' operation.")
                    
                    # Complexity (5 points)
                    # Simple heuristic: penalize deep nesting or a high number of parameters
                    parameter_count = len(operation.get('parameters', []))
                    if parameter_count < 10:
                        raw_score += self.scoring_breakdown['usability']['complexity']
                    else:
                        self.recommendations.append(f"The '{method.upper()} {path}' operation has a high number of parameters, which may indicate high complexity.")
                        
        return min(100, (raw_score / sum(self.scoring_breakdown['usability'].values())) * 100) if raw_score > 0 else 0

    def score_auth(self):
        """Scores authentication clarity based on the framework."""
        raw_score = 0
        max_score = 10
        
        # Security schemes (4 points) & Scope definitions (2 points)
        security_schemes = self.parser.spec_data.get('components', {}).get('securitySchemes', {})
        if security_schemes:
            raw_score += self.scoring_breakdown['auth']['security_schemes']
            for scheme_name, scheme_obj in security_schemes.items():
                if scheme_obj.get('type') == 'oauth2':
                    flows = scheme_obj.get('flows', {})
                    if any('scopes' in f for f in flows.values()):
                        raw_score += self.scoring_breakdown['auth']['scope_definitions']
                    else:
                        self.recommendations.append(f"The 'oauth2' security scheme '{scheme_name}' should have defined scopes for granular permissions.")
        else:
            self.recommendations.append("Define security schemes in the 'components' section to describe how to authenticate with the API.")
            
        # Auth examples (3 points) & Auth flow docs (1 point)
        if 'paths' in self.parser.spec_data:
            for path, methods in self.parser.spec_data['paths'].items():
                for method, operation in methods.items():
                    if 'security' in operation and operation['security']:
                        raw_score += self.scoring_breakdown['auth']['auth_examples']
                        raw_score += self.scoring_breakdown['auth']['auth_flow_docs']
                        break
        
        return min(100, (raw_score / sum(self.scoring_breakdown['auth'].values())) * 100) if raw_score > 0 else 0
