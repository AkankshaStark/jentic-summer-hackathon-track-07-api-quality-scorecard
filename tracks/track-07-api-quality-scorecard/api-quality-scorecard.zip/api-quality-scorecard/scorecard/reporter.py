# scorecard/reporter.py

import json
from string import Template
from datetime import datetime

class Reporter:
    """
    Generates various reports (HTML, JSON, Markdown) from a quality analysis.
    
    This class takes the analysis results and formats them into human-readable
    and machine-readable documents.
    """
    
    def __init__(self, report_data: dict, spec_title: str):
        """
        Initializes the reporter with the analysis results.

        Args:
            report_data (dict): The dictionary containing the analysis results.
            spec_title (str): The title of the API specification file.
        """
        self.report_data = report_data
        self.spec_title = spec_title

    def generate_json_report(self) -> str:
        """
        Generates a JSON report of the analysis.

        Returns:
            str: A JSON formatted string of the analysis data.
        """
        return json.dumps(self.report_data, indent=2)

    def generate_html_report(self) -> str:
        """
        Generates a comprehensive HTML report with charts.

        Returns:
            str: An HTML formatted string of the report.
        """
        template = Template("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Quality Scorecard: $spec_title</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"; margin: 0; padding: 2rem; background-color: #f4f7f9; color: #333; }
        .container { max-width: 960px; margin: 0 auto; background-color: #fff; padding: 2rem; border-radius: 12px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); }
        h1, h2 { color: #2c3e50; }
        .overall-score { font-size: 3rem; font-weight: bold; text-align: center; color: #27ae60; margin: 1rem 0; }
        .score-bar { background-color: #ecf0f1; border-radius: 8px; overflow: hidden; height: 20px; margin: 0.5rem 0; }
        .score-fill { height: 100%; background-color: #2ecc71; }
        .category-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1rem; }
        .category { background-color: #ecf0f1; padding: 1.5rem; border-radius: 8px; text-align: center; font-size: 1.1rem; font-weight: 500; }
        .category-score { font-size: 2rem; font-weight: bold; color: #3498db; }
        .summary-section { margin-top: 2rem; }
        .summary-section h3 { margin-bottom: 0.5rem; }
        ul { list-style-type: disc; padding-left: 1.5rem; }
        li { margin-bottom: 0.5rem; }
        canvas { max-width: 100%; height: auto; margin-top: 2rem; }
        footer { text-align: center; margin-top: 2rem; font-size: 0.9rem; color: #7f8c8d; }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js"></script>
</head>
<body>
    <div class="container">
        <h1>API Quality Scorecard Report</h1>
        <p style="text-align: center; color: #7f8c8d;">Generated on $report_date</p>
        
        <h2>Overall Score</h2>
        <div class="overall-score">$overall_score/100</div>
        
        <hr/>
        
        <h2>Category Scores</h2>
        <div class="category-grid">
            <div class="category">Documentation<br/><span class="category-score">$documentation_score/25</span></div>
            <div class="category">Schemas<br/><span class="category-score">$schemas_score/25</span></div>
            <div class="category">Error Handling<br/><span class="category-score">$errors_score/20</span></div>
            <div class="category">Usability<br/><span class="category-score">$usability_score/20</span></div>
            <div class="category">Authentication<br/><span class="category-score">$auth_score/10</span></div>
        </div>

        <canvas id="qualityChart"></canvas>

        <div class="summary-section">
            <h2>Analysis Summary</h2>
            <p><strong>Total Operations Analyzed:</strong> $total_operations</p>
            <h3>Issues Found ($issues_count)</h3>
            <ul>
                $issues_list
            </ul>
            <h3>Actionable Recommendations ($reco_count)</h3>
            <ul>
                $reco_list
            </ul>
        </div>
    </div>
    <footer>API Quality Scorecard Tool - Version 1.0</footer>
    
    <script>
        const ctx = document.getElementById('qualityChart');
        const labels = ["Documentation (25)", "Schemas (25)", "Error Handling (20)", "Usability (20)", "Authentication (10)"];
        const data = [$documentation_score, $schemas_score, $errors_score, $usability_score, $auth_score];

        new Chart(ctx, {
            type: 'radar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Category Scores',
                    data: data,
                    backgroundColor: 'rgba(52, 152, 219, 0.2)',
                    borderColor: 'rgba(52, 152, 219, 1)',
                    borderWidth: 1,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                scales: {
                    r: {
                        angleLines: {
                            display: false
                        },
                        suggestedMin: 0,
                        suggestedMax: 100,
                        pointLabels: {
                            font: {
                                size: 14
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
        """)
        
        issues_list = "".join([f"<li>{issue}</li>" for issue in self.report_data.get('issues_found', [])])
        reco_list = "".join([f"<li>{reco}</li>" for reco in self.report_data.get('recommendations', [])])
        
        template_data = {
            'spec_title': self.spec_title,
            'report_date': datetime.now().strftime("%B %d, %Y"),
            'overall_score': self.report_data.get('overall_score', 0),
            'documentation_score': self.report_data['category_scores'].get('documentation', 0),
            'schemas_score': self.report_data['category_scores'].get('schemas', 0),
            'errors_score': self.report_data['category_scores'].get('errors', 0),
            'usability_score': self.report_data['category_scores'].get('usability', 0),
            'auth_score': self.report_data['category_scores'].get('auth', 0),
            'total_operations': self.report_data.get('total_operations', 0),
            'issues_list': issues_list if issues_list else "<li>No issues found.</li>",
            'issues_count': len(self.report_data.get('issues_found', [])),
            'reco_list': reco_list if reco_list else "<li>No recommendations. Great job!</li>",
            'reco_count': len(self.report_data.get('recommendations', []))
        }
        
        return template.substitute(template_data)

    def generate_markdown_summary(self) -> str:
        """
        Generates a Markdown summary of the analysis.

        Returns:
            str: A Markdown formatted string.
        """
        overall_score = self.report_data.get('overall_score', 0)
        issues = self.report_data.get('issues_found', [])
        recommendations = self.report_data.get('recommendations', [])
        total_operations = self.report_data.get('total_operations', 0)
        
        markdown = f"""# API Quality Scorecard: {self.spec_title}

**Overall Score: {overall_score}/100**

---

### **Category Scores**
| Category | Score | Max Score |
| :--- | :--- | :--- |
| Documentation | {self.report_data['category_scores'].get('documentation', 0)} | 25 |
| Schemas | {self.report_data['category_scores'].get('schemas', 0)} | 25 |
| Error Handling | {self.report_data['category_scores'].get('errors', 0)} | 20 |
| Usability | {self.report_data['category_scores'].get('usability', 0)} | 20 |
| Authentication | {self.report_data['category_scores'].get('auth', 0)} | 10 |

---

### **Analysis Summary**
* **Total Operations:** {total_operations}

---

### **Issues Found**
"""
        if issues:
            for issue in issues:
                markdown += f"* {issue}\n"
        else:
            markdown += "* No issues found. Great job!\n"

        markdown += f"""
---

### **Actionable Recommendations**
"""
        if recommendations:
            for reco in recommendations:
                markdown += f"* {reco}\n"
        else:
            markdown += "* No recommendations. Looks great!\n"
            
        return markdown
