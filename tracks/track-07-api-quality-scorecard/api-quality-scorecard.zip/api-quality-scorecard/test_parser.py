# test_parser.py

import os
import sys
from pathlib import Path

# To make sure the import works from the root directory
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from scorecard.parser import OpenAPIParser
from jsonschema.exceptions import ValidationError

# Create a temporary directory and example spec files for testing
def setup_test_files():
    """Creates a temporary directory and example spec files for testing."""
    test_dir = Path('examples')
    test_dir.mkdir(exist_ok=True)
    
    valid_spec = """
openapi: 3.0.0
info:
  title: Test API
  version: 1.0.0
paths:
  /test:
    get:
      responses:
        '200':
          description: OK
"""
    invalid_spec = """
openapi: 3.0.0
info:
  title: Invalid API
  version: 1.0.0
# Missing paths key
"""
    
    with open(test_dir / 'valid-spec.yaml', 'w') as f:
        f.write(valid_spec)
        
    with open(test_dir / 'invalid-spec.yaml', 'w') as f:
        f.write(invalid_spec)

def test_parser_implementation():
    """Test that the parser can be imported and basic functionality works."""
    print("🔍 Testing OpenAPI Parser Implementation...")
    
    try:
        from scorecard.parser import OpenAPIParser
        # We only test import and object creation here, not validation
        parser = OpenAPIParser('examples/valid-spec.yaml')
        print("✅ Parser import and initialization successful")
        
        return True
    except ImportError as e:
        print(f"❌ Parser import failed: {e}")
        print("💡 You need to implement scorecard/parser.py inside the 'scorecard' directory.")
        return False
    except Exception as e:
        print(f"❌ Parser initialization failed: {e}")
        return False

def test_example_specs():
    """Test parsing of example specifications."""
    print("\n📖 Testing Example Specifications...")
    
    example_files = [
        'examples/valid-spec.yaml',
        'examples/invalid-spec.yaml'
    ]
    
    results = []
    
    for spec_file in example_files:
        if not os.path.exists(spec_file):
            print(f"⚠️  Example file not found: {spec_file}")
            continue
            
        print(f"Testing: {spec_file}")
        
        try:
            parser = OpenAPIParser(spec_file)
            is_valid = parser.validate_spec()
            
            # Debugging print statement
            print(f"  --> is_valid returned: {is_valid}")
            
            # This is the corrected check
            if 'valid' in spec_file and 'invalid' not in spec_file:
                if is_valid:
                    print(f"  ✅ {spec_file} validated successfully")
                    results.append(True)
                else:
                    print(f"  ❌ {spec_file} failed validation (expected to pass)")
                    results.append(False)
            else: # This is the invalid spec
                if not is_valid:
                    print(f"  ✅ {spec_file} failed validation as expected")
                    results.append(True)
                else:
                    print(f"  ❌ {spec_file} passed validation (expected to fail)")
                    results.append(False)
            
        except ValidationError as e:
            # The test should fail if a validation error is caught here, as validate_spec should handle it internally.
            print(f"  ❌ Unexpected ValidationError caught for {spec_file}: {e}")
            results.append(False)
        except Exception as e:
            print(f"  ❌ {spec_file} failed with an unexpected error: {e}")
            results.append(False)
    
    return all(results)

def test_error_handling():
    """Test parser error handling with problematic inputs."""
    print("\n🚨 Testing Error Handling...")
    
    error_test_cases = [
        {
            'name': 'Non-existent file',
            'input': 'non-existent-file.yaml',
        },
    ]
    
    for test_case in error_test_cases:
        print(f"Testing: {test_case['name']}")
        
        try:
            parser = OpenAPIParser(test_case['input'])
            parser.validate_spec()
            print(f"  ❌ Expected an exception but got no exception.")
            return False
        except FileNotFoundError:
            print(f"  ✅ Error handled appropriately (FileNotFoundError caught).")
    
    return True

def main():
    """Run all parser tests."""
    print("🧪 OpenAPI Parser Test Suite")
    print("=" * 50)
    
    setup_test_files()
    
    tests = [
        test_parser_implementation,
        test_example_specs,
        test_error_handling
    ]
    
    results = []
    
    for test_func in tests:
        try:
            result = test_func()
            results.append(result)
        except Exception as e:
            print(f"❌ Test {test_func.__name__} failed with error: {e}")
            results.append(False)
    
    print("\n" + "=" * 50)
    print("📊 Test Results Summary:")
    
    passed = sum(results)
    total = len(results)
    
    if passed == total:
        print(f"🎉 All tests passed! ({passed}/{total})")
        print("\n✅ Parser implementation is ready for development")
        return 0
    else:
        print(f"❌ Some tests failed ({passed}/{total})")
        return 1

if __name__ == "__main__":
    sys.exit(main())

