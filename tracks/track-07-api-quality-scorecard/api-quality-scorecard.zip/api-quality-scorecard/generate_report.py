# generate_report.py

import sys
import json
from pathlib import Path

# Append the parent directory to the system path to allow importing modules
sys.path.append(str(Path(__file__).resolve().parent))
from scorecard.parser import OpenAPIParser
from scorecard.analyzer import QualityAnalyzer
from scorecard.reporter import Reporter

def main():
    """
    Main function to orchestrate the report generation process.
    """
    print("🚀 Generating API Quality Scorecard Report...\n")

    # Define the path to the OpenAPI specification file.
    # We use the absolute path relative to the script's location.
    script_dir = Path(__file__).resolve().parent
    spec_path = script_dir / 'examples' / 'petstore-expanded.yaml'

    try:
        # Step 1: Parsing and validating the API specification
        print("1. Parsing and validating the API specification...")
        parser = OpenAPIParser(str(spec_path))
        parser.validate_spec()
        print("  ✅ Specification is valid.\n")

        # Step 2: Analyzing API quality
        print("2. Analyzing API quality...")
        analyzer = QualityAnalyzer(parser)
        report_data = analyzer.analyze()
        print("  ✅ Analysis complete.\n")
        
        # Step 3: Generating reports
        print("3. Generating reports...\n")
        
        # Initialize the reporter with the analysis results and the spec's name
        reporter = Reporter(report_data, spec_path.name)

        # Generate JSON Report and print to console
        json_report = reporter.generate_json_report()
        print("--- JSON Report ---")
        print(json_report)
        print("-------------------\n")

        # Generate HTML Report and save to file
        html_content = reporter.generate_html_report()
        report_path = script_dir / 'report.html'
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        print(f"  ✅ HTML report saved to '{report_path}'\n")
        
        # Generate Markdown Summary and print to console
        markdown_summary = reporter.generate_markdown_summary()
        print("--- Markdown Summary ---")
        print(markdown_summary)
        print("------------------------\n")

        # Step 4: Displaying actionable recommendations
        print("4. Actionable Recommendations...")
        if report_data['recommendations']:
            for rec in report_data['recommendations']:
                print(f"  • {rec}")
        else:
            print("  • No specific recommendations at this time. The API has great quality!")
            
        print("\n🎉 Report generation complete!")

    except FileNotFoundError as e:
        print(f"❌ Error: {e}")
        print("Please ensure the 'examples' directory and the 'petstore-expanded.yaml' file are in the same directory as the 'generate_report.py' script.")
        sys.exit(1)
    except Exception as e:
        print(f"❌ An unexpected error occurred: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
